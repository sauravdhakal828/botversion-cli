# botversion-sdk-python/botversion-sdk/scanner.py
import re
import inspect
import typing
from typing import Annotated
import ast
import textwrap


def scan_routes(app, framework):
    result = []
    if framework == "fastapi":
        result = scan_fastapi_routes(app)
    elif framework == "flask":
        result = scan_flask_routes(app)
    elif framework == "django":
        result = scan_django_routes()
    # ── NEW frameworks ────────────────────────────────────────────────────
    elif framework == "starlette":
        result = scan_starlette_routes(app)
    elif framework == "sanic":
        result = scan_sanic_routes(app)
    elif framework == "falcon":
        result = scan_falcon_routes(app)
    elif framework == "bottle":
        result = scan_bottle_routes(app)
    elif framework == "aiohttp":
        result = scan_aiohttp_routes(app)
    elif framework == "tornado":
        result = scan_tornado_routes(app)
    elif framework == "pyramid":
        result = scan_pyramid_routes(app)
    elif framework == "cherrypy":
        result = scan_cherrypy_routes(app)

    for endpoint in result:
        if "routeParamMap" not in endpoint:
            endpoint["routeParamMap"] = build_route_param_map(endpoint.get("path", ""))

    return result


# ── FastAPI ──────────────────────────────────────────────────────────────────

def scan_fastapi_routes(app):
    endpoints = []
    seen = set()

    try:
        for route in app.routes:
            # Skip non-API routes (static files, docs, websockets, etc.)
            if not hasattr(route, "methods") or not route.methods:
                continue

            path = route.path
            # Skip docs/openapi
            SKIP_PREFIXES = ["/admin", "/static", "/media"]
            if path in ("/docs", "/redoc", "/openapi.json"):
                continue
            if any(path.startswith(p) for p in SKIP_PREFIXES):
                continue

            methods = [m for m in route.methods if m not in ("HEAD", "OPTIONS")]

            for method in methods:
                normalized_path = re.sub(r"\{([^}]+)\}", r":\1", path)
                normalized_path = normalized_path.rstrip("/") or "/"
                key = f"{method}:{normalized_path}"
                if key in seen:
                    continue
                seen.add(key)

                params = extract_path_params(normalized_path)
                handler_name = getattr(route, "name", None) or getattr(
                    getattr(route, "endpoint", None), "__name__", None
                )

                endpoints.append({
                    "method": method,
                    "path": normalized_path,
                    "description": generate_description(method, normalized_path, handler_name),
                    "requestBody": extract_request_body_schema(route, method),
                    "responseBody": extract_fastapi_response_schema(route) or extract_static_response_from_callable(_resolve_view_handler(getattr(route, "endpoint", None), method)),
                    "detectedBy": "static-scan",
                })

    except Exception:
        pass

    return endpoints


# ── Flask ────────────────────────────────────────────────────────────────────

def scan_flask_routes(app):
    endpoints = []
    seen = set()

    SKIP_PREFIXES = ("/swaggerui", "/static", "/_", "/admin", "/media")
    SKIP_EXACT = ("/swagger.json", "/redoc", "/openapi.json", "/docs", "/favicon.ico")

    try:
        for rule in app.url_map.iter_rules():
            # Skip Flask internal static routes
            if rule.endpoint == "static":
                continue

            # Skip common documentation/UI routes
            if any(rule.rule.startswith(p) for p in SKIP_PREFIXES):
                continue
            if rule.rule in SKIP_EXACT:
                continue

            # Normalize Flask path format <int:id> → :id
            path = normalize_flask_path(rule.rule).rstrip("/") or "/"
            methods = [m for m in rule.methods if m not in ("HEAD", "OPTIONS")]

            for method in methods:
                key = f"{method}:{path}"
                if key in seen:
                    continue
                seen.add(key)

                params = extract_path_params(path)

                # Try to get the handler function name for description
                handler_fn = app.view_functions.get(rule.endpoint)
                handler_name = getattr(handler_fn, "__name__", rule.endpoint)

                endpoints.append({
                    "method": method,
                    "path": path,
                    "description": generate_description(method, path, handler_name),
                    "requestBody": (
                        extract_flask_schema(handler_fn, method) or
                        extract_restx_resource_schema(app, rule, method) or
                        (build_param_schema(params) if method != "GET" and params else None)
                    ),
                    "responseBody": extract_static_response_from_callable(_resolve_view_handler(handler_fn, method)),
                    "detectedBy": "static-scan",
                })

    except Exception:
        pass

    return endpoints


def join_paths(prefix, suffix):
    """
    Safely join two path segments without creating double slashes.
    """
    # Strip trailing slash from prefix, leading slash from suffix
    prefix = prefix.rstrip("/")
    suffix = suffix.lstrip("/")
    if not suffix:
        return prefix or "/"
    return prefix + "/" + suffix


# ── Django ───────────────────────────────────────────────────────────────────

def scan_django_routes():
    endpoints = []
    seen = set()

    try:
        from django.urls import get_resolver
        from django.urls.resolvers import URLPattern, URLResolver

        resolver = get_resolver()
        _walk_django_patterns(resolver.url_patterns, "", endpoints, seen)
    except Exception:
        pass

    return endpoints


def extract_drf_schema(callback, method):
    """
    Extract request body schema from a DRF serializer.
    Works with APIView, GenericAPIView, ViewSet.
    Returns a JSON schema dict or None.
    """
    if method.upper() == "GET":
        return None

    try:
        # Get the view class
        view_class = None
        if hasattr(callback, "view_class"):
            view_class = callback.view_class
        elif hasattr(callback, "cls"):
            view_class = callback.cls

        if not view_class:
            return None

        # Try to get serializer class
        serializer_class = None

        # Direct attribute
        if hasattr(view_class, "serializer_class"):
            serializer_class = view_class.serializer_class

        # Fallback — try calling get_serializer_class() on the view
        if not serializer_class and hasattr(view_class, "get_serializer_class"):
            try:
                serializer_class = view_class().get_serializer_class()
            except Exception:
                pass

        # Instantiate the serializer to inspect fields
        serializer = serializer_class()
        properties = {}
        required = []

        for field_name, field in serializer.fields.items():
            # Skip read-only fields — they don't go in request body
            if getattr(field, "read_only", False):
                continue

            # Map DRF field types to JSON schema types
            field_type = _drf_field_to_json_type(field)
            properties[field_name] = {
                "type": field_type,
                "description": field_name.replace("_", " ").title(),
            }

            # A field is required if it's not optional and has no default
            from rest_framework.fields import empty
            is_required = (
                getattr(field, "required", True) and
                not getattr(field, "allow_null", False) and
                getattr(field, "default", empty) is empty  # ← only truly required if no default set
            )
            if is_required:
                required.append(field_name)

        if not properties:
            return None

        result = {"type": "object", "properties": properties}
        if required:
            result["required"] = required

        return result

    except Exception:
        pass

    # Strategy 2 — request.data / request.POST pattern
    try:
        src = None

        if hasattr(callback, "view_class"):
            method_fn = getattr(callback.view_class, method.lower(), None)
            if method_fn:
                src = inspect.getsource(method_fn)
        elif hasattr(callback, "cls"):
            method_fn = getattr(callback.cls, method.lower(), None)
            if method_fn:
                src = inspect.getsource(method_fn)
        else:
            src = inspect.getsource(callback)

        if src:
            fields = set()

            for m in re.finditer(r"request\.data(?:\.get\(|\[)\s*['\"]([a-zA-Z_][a-zA-Z0-9_]*)['\"]", src):
                fields.add(m.group(1))

            for m in re.finditer(r"request\.POST(?:\.get\(|\[)\s*['\"]([a-zA-Z_][a-zA-Z0-9_]*)['\"]", src):
                fields.add(m.group(1))

            var_match = re.search(r"(\w+)\s*=\s*request\.data", src)
            if var_match:
                var = var_match.group(1)
                for m in re.finditer(rf"{var}(?:\.get\(|\[)\s*['\"]([a-zA-Z_][a-zA-Z0-9_]*)['\"]", src):
                    fields.add(m.group(1))

            for m in re.finditer(r"validated_data(?:\.get\(|\[)\s*['\"]([a-zA-Z_][a-zA-Z0-9_]*)['\"]", src):
                fields.add(m.group(1))

            # SomeSerializer(data=request.data) — extract serializer class and inspect its fields
            for m in re.finditer(r"(\w+Serializer)\s*\(", src):
                serializer_name = m.group(1)
                try:
                    import sys
                    for module in sys.modules.values():
                        serializer_cls = getattr(module, serializer_name, None)
                        if serializer_cls and hasattr(serializer_cls, "_declared_fields"):
                            for field_name, field in serializer_cls._declared_fields.items():
                                if not getattr(field, "read_only", False):
                                    fields.add(field_name)
                            break
                        if serializer_cls and hasattr(serializer_cls, "Meta") and hasattr(getattr(serializer_cls, "Meta"), "fields"):
                            meta_fields = serializer_cls.Meta.fields
                            if isinstance(meta_fields, (list, tuple)):
                                for field_name in meta_fields:
                                    if field_name != "__all__":
                                        fields.add(field_name)
                            break
                except Exception:
                    pass

            if fields:
                properties = {f: {"type": infer_field_type(f, src), "description": f.replace("_", " ").title()} for f in fields}
                return {"type": "object", "properties": properties}

    except Exception:
        return None

    return None


def _drf_field_to_json_type(field):
    """Map a DRF field instance to a JSON schema type string."""
    from rest_framework import fields as drf_fields
    try:
        from rest_framework import fields as drf_fields
        if isinstance(field, (drf_fields.IntegerField,)):
            return "integer"
        if isinstance(field, (drf_fields.FloatField, drf_fields.DecimalField)):
            return "number"
        if isinstance(field, drf_fields.BooleanField):
            return "boolean"
        if isinstance(field, drf_fields.ListField):
            return "array"
    except ImportError:
        pass
    return "string"


def extract_flask_schema(view_func, method):
    """
    Extract request body schema from Flask view functions.
    Supports: Marshmallow, Flask-RESTX, Flask-Pydantic, WTForms
    """
    if method.upper() == "GET":
        return None
    try:
        hints = typing.get_type_hints(view_func) if callable(view_func) else {}
    except Exception:
        pass

    try:
        # ── 1. Flask-RESTX / Flask-RESTPlus ──────────────────────────────
        # Decorators store expect/body info in __apidoc__
        apidoc = getattr(view_func, "__apidoc__", None)
        if apidoc:
            expects = apidoc.get("expects", [])
            for expect in expects:
                if hasattr(expect, "resolved"):
                    schema = expect.resolved
                    properties = {}
                    required = []
                    for field_name, field in schema.items():
                        properties[field_name] = {
                            "type": _restx_field_to_json_type(field),
                            "description": field_name.replace("_", " ").title(),
                        }
                        if field.required:
                            required.append(field_name)
                    if properties:
                        result = {"type": "object", "properties": properties}
                        if required:
                            result["required"] = required
                        return result

        # ── 2. Marshmallow schema ─────────────────────────────────────────
        # Some devs attach schema directly to view function
        schema = (
            getattr(view_func, "_schema", None) or
            getattr(view_func, "schema", None) or
            getattr(view_func, "_marshmallow_schema", None)
        )
        if schema is not None:
            marshmallow_result = _extract_marshmallow_schema(schema)
            if marshmallow_result:
                return marshmallow_result

        # ── 3. Flask-RESTX MethodView / Resource ─────────────────────────
        # Check if the view class has a schema on the method
        view_class = getattr(view_func, "view_class", None)
        if view_class:
            method_fn = getattr(view_class, method.lower(), None)
            if method_fn:
                # Check for marshmallow schema on method
                schema = (
                    getattr(method_fn, "_schema", None) or
                    getattr(method_fn, "schema", None)
                )
                if schema:
                    marshmallow_result = _extract_marshmallow_schema(schema)
                    if marshmallow_result:
                        return marshmallow_result

                # Check for RESTX expect decorator
                apidoc = getattr(method_fn, "__apidoc__", None)
                if apidoc:
                    expects = apidoc.get("expects", [])
                    for expect in expects:
                        if hasattr(expect, "resolved"):
                            schema = expect.resolved
                            properties = {}
                            required = []
                            for field_name, field in schema.items():
                                properties[field_name] = {
                                    "type": _restx_field_to_json_type(field),
                                    "description": field_name.replace("_", " ").title(),
                                }
                                if field.required:
                                    required.append(field_name)
                            if properties:
                                result = {"type": "object", "properties": properties}
                                if required:
                                    result["required"] = required
                                return result

        # ── 4. Pydantic model attached to view ────────────────────────────
        pydantic_model = getattr(view_func, "_pydantic_model", None)
        if pydantic_model and hasattr(pydantic_model, "model_json_schema"):
            schema = pydantic_model.model_json_schema()
            return schema
        if pydantic_model and hasattr(pydantic_model, "schema"):
            schema = pydantic_model.schema()
            return schema

    except Exception:
        pass

    # Strategy 5 — plain request.json / request.get_json() / request.form pattern
    try:
        src = inspect.getsource(view_func)
        fields = set()

        # request.json.get('field') or request.json['field']
        for m in re.finditer(r"request\.json(?:\.get\(|)\s*['\"]([a-zA-Z_][a-zA-Z0-9_]*)['\"]", src):
            fields.add(m.group(1))

        # request.get_json().get('field') or request.get_json()['field']
        for m in re.finditer(r"request\.get_json\(\)(?:\.get\(|)\s*['\"]([a-zA-Z_][a-zA-Z0-9_]*)['\"]", src):
            fields.add(m.group(1))

        # data = request.get_json() then data['field'] or data.get('field')
        var_match = re.search(r"(\w+)\s*=\s*request\.get_json\(\)", src)
        if var_match:
            var = var_match.group(1)
            for m in re.finditer(rf"{var}(?:\.get\(|\[)\s*['\"]([a-zA-Z_][a-zA-Z0-9_]*)['\"]", src):
                fields.add(m.group(1))

        # request.form.get('field') or request.form['field']
        for m in re.finditer(r"request\.form(?:\.get\(|\[)\s*['\"]([a-zA-Z_][a-zA-Z0-9_]*)['\"]", src):
            fields.add(m.group(1))

        if fields:
            properties = {f: {"type": infer_field_type(f, src)} for f in fields}
            return {"type": "object", "properties": properties}

    except Exception:
        pass

    return None



def extract_restx_resource_schema(app, rule, method):
    """
    Handles Flask-RESTX Resource classes.
    Flask-RESTX stores schema info on the Resource class method,
    not on the Flask view function.
    """
    try:
        handler_fn = app.view_functions.get(rule.endpoint)
        if not handler_fn:
            return None

        # Flask-RESTX attaches the Resource class as view_class
        view_class = getattr(handler_fn, "view_class", None)
        if not view_class:
            return None

        # Get the actual method e.g. Register.post
        method_fn = getattr(view_class, method.lower(), None)
        if not method_fn:
            return None

        # @rest_api.expect() stores info in __apidoc__
        apidoc = getattr(method_fn, "__apidoc__", None)
        if not apidoc:
            return None

        # Flask-RESTX uses "expect" key (not "expects")
        expects = apidoc.get("expect", [])
        for expect_entry in expects:
            model = expect_entry[0] if isinstance(expect_entry, (list, tuple)) else expect_entry
            if hasattr(model, "resolved"):
                properties = {}
                required = []
                for field_name, field in model.resolved.items():
                    properties[field_name] = {
                        "type": _restx_field_to_json_type(field),
                        "description": field_name.replace("_", " ").title(),
                    }
                    if getattr(field, "required", False):
                        required.append(field_name)
                if properties:
                    result = {"type": "object", "properties": properties}
                    if required:
                        result["required"] = required
                    return result

    except Exception:
        pass
    return None



def _extract_marshmallow_schema(schema):
    """
    Extract JSON schema properties from a Marshmallow schema instance or class.
    """
    try:
        import marshmallow

        # Instantiate if it's a class
        if isinstance(schema, type):
            schema = schema()

        if not isinstance(schema, marshmallow.Schema):
            return None

        properties = {}
        required = []

        for field_name, field in schema.fields.items():
            # Skip dump_only fields (read-only)
            if getattr(field, "dump_only", False):
                continue

            field_type = _marshmallow_field_to_json_type(field)
            properties[field_name] = {
                "type": field_type,
                "description": field_name.replace("_", " ").title(),
            }

            if getattr(field, "required", False):
                required.append(field_name)

        if not properties:
            return None

        result = {"type": "object", "properties": properties}
        if required:
            result["required"] = required
        return result

    except ImportError:
        return None
    except Exception as e:
        return None


def _marshmallow_field_to_json_type(field):
    """Map Marshmallow field types to JSON schema types."""
    try:
        import marshmallow.fields as ma_fields
        if isinstance(field, ma_fields.Integer):
            return "integer"
        if isinstance(field, (ma_fields.Float, ma_fields.Decimal)):
            return "number"
        if isinstance(field, ma_fields.Boolean):
            return "boolean"
        if isinstance(field, (ma_fields.List, ma_fields.Tuple)):
            return "array"
        if isinstance(field, ma_fields.Dict):
            return "object"
    except ImportError:
        pass
    return "string"


def _restx_field_to_json_type(field):
    """Map Flask-RESTX field types to JSON schema types."""
    type_name = type(field).__name__.lower()
    if "integer" in type_name:
        return "integer"
    if "float" in type_name:
        return "number"
    if "boolean" in type_name:
        return "boolean"
    if "list" in type_name:
        return "array"
    return "string"


def _walk_django_patterns(patterns, prefix, endpoints, seen):
    try:
        from django.urls.resolvers import URLPattern, URLResolver
    except ImportError:
        return
    
    SKIP_PREFIXES = ["/admin", "/static", "/media"]

    for pattern in patterns:
        if isinstance(pattern, URLResolver):
            sub_prefix = join_paths(prefix, _django_pattern_to_path(str(pattern.pattern)))

            if any(sub_prefix.startswith(p) for p in SKIP_PREFIXES):
                continue

            _walk_django_patterns(pattern.url_patterns, sub_prefix, endpoints, seen)

        elif isinstance(pattern, URLPattern):
            path = join_paths(prefix, _django_pattern_to_path(str(pattern.pattern)))
            methods = _detect_django_methods(pattern.callback)
            handler_name = getattr(pattern.callback, "__name__", None)

            for method in methods:
                key = f"{method}:{path}"
                if key in seen:
                    continue
                seen.add(key)

                params = extract_path_params(path)
                endpoints.append({
                    "method": method,
                    "path": path,
                    "description": generate_description(method, path, handler_name),
                    "requestBody": extract_drf_schema(pattern.callback, method) or (build_param_schema(params) if method != "GET" and params else None),
                    "responseBody": extract_static_response_from_callable(_resolve_view_handler(pattern.callback, method)),
                    "detectedBy": "static-scan",
                })


_METHOD_ORDER = ["GET", "POST", "PUT", "PATCH", "DELETE"]


def _detect_methods_from_source(fn):
    """
    Reads a function-based view's code to learn which HTTP methods it handles
    (method checks and Django decorators). Returns None if nothing is recognised.
    """
    try:
        fn = inspect.unwrap(fn)
        tree = ast.parse(textwrap.dedent(inspect.getsource(fn)))
    except Exception:
        return None

    from_decorators, checked, guarded = set(), set(), set()

    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            # decorators that restrict methods, e.g. @require_POST, @require_http_methods([...])
            for dec in node.decorator_list:
                target = dec.func if isinstance(dec, ast.Call) else dec
                name = target.attr if isinstance(target, ast.Attribute) else getattr(target, "id", "")
                if name == "require_POST":
                    from_decorators.add("POST")
                elif name in ("require_GET", "require_safe"):
                    from_decorators.add("GET")
                elif name == "require_http_methods" and isinstance(dec, ast.Call) and dec.args:
                    arg = dec.args[0]
                    if isinstance(arg, (ast.List, ast.Tuple, ast.Set)):
                        for e in arg.elts:
                            if isinstance(e, ast.Constant) and isinstance(e.value, str):
                                from_decorators.add(e.value.upper())
        elif isinstance(node, ast.Compare):
            info = _method_test(node)
            if info:
                methods, negated = info
                (guarded if negated else checked).update(methods)

    def ordered(found):
        return [m for m in _METHOD_ORDER if m in found] or None

    if from_decorators:
        return ordered(from_decorators)      # decorator states the allowed methods exactly
    if guarded:
        return ordered(guarded)              # "if method != X: reject" means only X is accepted
    if checked:
        return ordered(checked | {"GET"})    # "if method == X: ..." leaves other requests falling through
    return None


def _detect_django_methods(callback):
    """
    Detect HTTP methods from a Django view.
    Handles class-based views, DRF ViewSets/APIViews, and function-based views.
    """
    # Class-based view — has http_method_names
    if hasattr(callback, "view_class"):
        cls = callback.view_class
        all_methods = ["GET", "POST", "PUT", "PATCH", "DELETE"]
        return [m for m in all_methods if hasattr(cls, m.lower())]

    # DRF ViewSet — has actions dict
    if hasattr(callback, "actions"):
        return [m.upper() for m in callback.actions.keys()]

    # DRF APIView — has http_method_names on the cls
    if hasattr(callback, "cls"):
        cls = callback.cls
        all_methods = ["GET", "POST", "PUT", "PATCH", "DELETE"]
        return [m for m in all_methods if hasattr(cls, m.lower())]

    # Function-based view — read its code for method checks/decorators;
    # fall back to GET + POST only when nothing recognisable is found
    return _detect_methods_from_source(callback) or ["GET", "POST"]


def _django_pattern_to_path(pattern):
    """
    Convert Django URL pattern to a clean path string.
    e.g. "api/users/(?P<id>[0-9]+)/" → "/api/users/:id"
    """
    # Remove regex named groups
    path = re.sub(r"\(\?P<([^>]+)>[^)]+\)", r":\1", pattern)
    # New-style Django path converters <int:pk> → :pk
    path = re.sub(r"<(?:[^:>]+:)?([^>]+)>", r":\1", path)
    # Remove remaining regex artifacts
    path = re.sub(r"[\\^$]", "", path)
    # Ensure leading slash
    if not path.startswith("/"):
        path = "/" + path
    if path != "/" and not path.endswith("/"):
        path = path + "/"
    return path


# ── Shared utilities ─────────────────────────────────────────────────────────

def normalize_flask_path(rule):
    """
    Convert Flask path format to standard :param format.
    /users/<int:id> → /users/:id
    /users/<string:name> → /users/:name
    /users/<id> → /users/:id
    """
    return re.sub(r"<(?:[^:>]+:)?([^>]+)>", r":\1", rule)


def infer_field_type(field_name, source_code):
    """Infer the type of a field from how it's used in source code."""
    import re

    # Check if used as array/list
    array_patterns = [
        rf"{field_name}\s*\.\s*(append|extend|pop|remove|sort|reverse|__iter__|__len__)",
        rf"for\s+\w+\s+in\s+{field_name}\b",
        rf"len\s*\(\s*{field_name}\s*\)",
        rf"isinstance\s*\(\s*{field_name}\s*,\s*(list|List)\s*\)",
        rf"\[\s*\.\.\.{field_name}\s*\]",
    ]
    if any(re.search(p, source_code) for p in array_patterns):
        return "array"

    # Check if used as number
    number_patterns = [
        rf"{field_name}\s*[+\-*/%]\s*\d",
        rf"int\s*\(\s*{field_name}\s*\)",
        rf"float\s*\(\s*{field_name}\s*\)",
        rf"isinstance\s*\(\s*{field_name}\s*,\s*(int|float)\s*\)",
        rf"not\s+isinstance\s*\(\s*{field_name}\s*,\s*(int|float)\s*\)",
        rf"type\s*\(\s*{field_name}\s*\)\s*is\s*(not\s+)?(int|float)",
    ]
    if any(re.search(p, source_code) for p in number_patterns):
        return "number"

    # Check if used as boolean
    bool_patterns = [
        rf"{field_name}\s*==\s*(True|False)",
        rf"(True|False)\s*==\s*{field_name}",
        rf"isinstance\s*\(\s*{field_name}\s*,\s*bool\s*\)",
        rf"bool\s*\(\s*{field_name}\s*\)",
        rf"type\s*\(\s*{field_name}\s*\)\s*is\s*(not\s+)?bool",
        rf"not\s+isinstance\s*\(\s*{field_name}\s*,\s*bool\s*\)",
    ]
    if any(re.search(p, source_code) for p in bool_patterns):
        return "boolean"

    return "string"



def extract_path_params(path):
    """Extract :param names from a path like /users/:id/posts/:postId"""
    return re.findall(r":([a-zA-Z_][a-zA-Z0-9_]*)", path)


def build_param_schema(params):
    """
    Build a simple schema from path param names.
    Mirrors JS buildParamSchema()
    """
    properties = {p: {"type": "string"} for p in params}
    return {"type": "object", "properties": properties}

def build_route_param_map(route_path):
    """
    Gives route params more descriptive names based on their parent
    segment, mirroring the JS SDK's buildRouteParamMap().
    e.g. /projects/:id -> {"id": "projectId"}
    """
    param_map = {}
    parts = [p for p in route_path.split("/") if p]

    for i, part in enumerate(parts):
        match = re.match(r"^:([a-zA-Z_][a-zA-Z0-9_]*)$", part)
        if not match:
            continue
        param_name = match.group(1)

        if param_name not in ("id", "slug", "param"):
            param_map[param_name] = param_name
            continue

        parent_segment = parts[i - 1] if i > 0 else None
        if parent_segment:
            clean_parent = parent_segment.lstrip(":")
            singular = re.sub(r"ies$", "y", clean_parent)
            if singular == clean_parent:
                singular = re.sub(r"s$", "", clean_parent)
            param_map[param_name] = singular + "Id"
        else:
            param_map[param_name] = "id"

    return param_map


def generate_description(method, path, handler_name=None):
    """
    Generate a human-readable description for an endpoint.
    Mirrors JS scanner logic.
    """
    if handler_name and handler_name not in ("anonymous", "dispatch", ""):
        # Convert snake_case → readable words
        name = re.sub(r"_", " ", handler_name)
        # Convert camelCase → readable words
        name = re.sub(r"([A-Z])", r" \1", name)
        return name.strip().title()

    segments = [s for s in path.split("/") if s and not s.startswith(":")]
    resource = segments[-1] if segments else "resource"
    resource = resource.replace("_", " ").replace("-", " ").title()

    verbs = {
        "GET": "Get",
        "POST": "Create",
        "PUT": "Update",
        "PATCH": "Partially Update",
        "DELETE": "Delete",
    }

    verb = verbs.get(method, method.title())
    return f"{verb} {resource}"



def extract_request_body_schema(route, method):
    if method not in ("POST", "PUT", "PATCH"):
        return None

    try:
        # path param names — we must exclude these from body
        path_param_names = set()
        if hasattr(route, "dependant") and hasattr(route.dependant, "path_params"):
            path_param_names = {f.name for f in route.dependant.path_params}

        # Strategy 1: route.dependant.body_params
        if hasattr(route, "dependant") and route.dependant.body_params:
            properties = {}
            required = []

            for field in route.dependant.body_params:
                field_name = field.name

                # Skip path params — they are NOT body fields
                if field_name in path_param_names:
                    continue

                annotation = None
                if hasattr(field, "field_info") and hasattr(field.field_info, "annotation"):
                    annotation = field.field_info.annotation
                if annotation is None and hasattr(field, "outer_type_"):
                    annotation = field.outer_type_
                if annotation is None:
                    annotation = getattr(field, "type_", None)

                if annotation and hasattr(annotation, "model_json_schema"):
                    schema = annotation.model_json_schema()
                    properties.update(schema.get("properties", {}))
                    required.extend(schema.get("required", []))
                elif annotation and hasattr(annotation, "schema"):
                    schema = annotation.schema()
                    properties.update(schema.get("properties", {}))
                    required.extend(schema.get("required", []))
                else:
                    type_map = {"int": "integer", "float": "number", "bool": "boolean", "str": "string"}
                    python_type = getattr(annotation, "__name__", "string") if annotation else "string"
                    properties[field_name] = {"type": type_map.get(python_type, "string")}
                    required.append(field_name)

            if properties:
                result = {"type": "object", "properties": properties}
                if required:
                    result["required"] = list(set(required))
                return result

        # Strategy 2: inspect type hints on endpoint function directly
        endpoint_fn = getattr(route, "endpoint", None)
        if endpoint_fn:
            hints = typing.get_type_hints(endpoint_fn)
            sig = inspect.signature(endpoint_fn)
            properties = {}
            required = []

            skip = {"request", "response", "background_tasks", "db", "session", "user", "current_user"}

            for param_name, param in sig.parameters.items():
                if param_name in skip or param_name in path_param_names:
                    continue
                annotation = hints.get(param_name)
                if annotation is None:
                    continue
                # Unwrap Annotated[Model, Body(...)] if present
                origin = getattr(annotation, "__origin__", None)
                if origin is Annotated:
                    args = annotation.__args__
                    if args:
                        annotation = args[0]
                if hasattr(annotation, "model_json_schema"):
                    schema = annotation.model_json_schema()
                    properties.update(schema.get("properties", {}))
                    required.extend(schema.get("required", []))
                elif hasattr(annotation, "schema"):
                    schema = annotation.schema()
                    properties.update(schema.get("properties", {}))
                    required.extend(schema.get("required", []))

            if properties:
                result = {"type": "object", "properties": properties}
                if required:
                    result["required"] = list(set(required))
                return result

    except Exception:
        return None

    return None


# ── Starlette ─────────────────────────────────────────────────────────────────
# Starlette is what FastAPI is built on, so route scanning is almost identical

def scan_starlette_routes(app):
    endpoints = []
    seen = set()

    try:
        for route in app.routes:
            if not hasattr(route, "methods") or not route.methods:
                continue

            path = route.path
            if path in ("/docs", "/redoc", "/openapi.json"):
                continue

            methods = [m for m in route.methods if m not in ("HEAD", "OPTIONS")]

            for method in methods:
                normalized_path = re.sub(r"\{([^}]+)\}", r":\1", path)
                normalized_path = normalized_path.rstrip("/") or "/"
                key = f"{method}:{normalized_path}"
                if key in seen:
                    continue
                seen.add(key)

                handler_name = getattr(route, "name", None)
                endpoints.append({
                    "method": method,
                    "path": normalized_path,
                    "description": generate_description(method, normalized_path, handler_name),
                    "requestBody": None,
                    "responseBody": extract_static_response_from_callable(_resolve_view_handler(getattr(route, "endpoint", None), method)),
                    "detectedBy": "static-scan",
                })

    except Exception:
        pass

    return endpoints


# ── Sanic ─────────────────────────────────────────────────────────────────────
# Sanic stores routes in app.router which has a routes_all dict

def scan_sanic_routes(app):
    endpoints = []
    seen = set()

    try:
        # Sanic 21+ uses app.router.routes
        routes = getattr(app.router, "routes", None) or getattr(app.router, "routes_all", {})

        # routes can be a dict or a list depending on Sanic version
        if isinstance(routes, dict):
            routes = routes.values()

        for route in routes:
            path = getattr(route, "path", None) or getattr(route, "uri", None)
            if not path:
                continue

            # Normalize <param> or <param:type> → :param
            normalized_path = re.sub(r"<([^:>]+)(?::[^>]+)?>", r":\1", path)
            normalized_path = normalized_path.rstrip("/") or "/"

            methods = getattr(route, "methods", ["GET"])
            if not methods:
                methods = ["GET"]

            for method in methods:
                method = method.upper()
                if method in ("HEAD", "OPTIONS"):
                    continue

                key = f"{method}:{normalized_path}"
                if key in seen:
                    continue
                seen.add(key)

                handler = getattr(route, "handler", None)
                handler_name = getattr(handler, "__name__", None)

                endpoints.append({
                    "method": method,
                    "path": normalized_path,
                    "description": generate_description(method, normalized_path, handler_name),
                    "requestBody": None,
                    "responseBody": extract_static_response_from_callable(_resolve_view_handler(handler, method)),
                    "detectedBy": "static-scan",
                })

    except Exception:
        pass

    return endpoints


# ── Falcon ────────────────────────────────────────────────────────────────────
# Falcon stores routes in its router. We walk the router tree to find them.

def scan_falcon_routes(app):
    endpoints = []
    seen = set()

    ALL_METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE"]

    try:
        # Falcon 3.x
        router = getattr(app, "_router", None)
        if router is None:
            return endpoints

        # Walk the router tree
        def walk_falcon_node(node, prefix=""):
            path = prefix + (getattr(node, "raw_segment", "") or "")
            if not path.startswith("/"):
                path = "/" + path

            resource = getattr(node, "resource", None)
            if resource is not None:
                # Check which HTTP methods the resource handles
                for method in ALL_METHODS:
                    responder_name = f"on_{method.lower()}"
                    if hasattr(resource, responder_name):
                        # Normalize {param} or {param:type} → :param
                        normalized = re.sub(r"\{([^:}]+)(?::[^}]+)?\}", r":\1", path)
                        normalized = normalized.rstrip("/") or "/"
                        key = f"{method}:{normalized}"
                        if key not in seen:
                            seen.add(key)
                            endpoints.append({
                                "method": method,
                                "path": normalized,
                                "description": generate_description(method, normalized, None),
                                "requestBody": None,
                                "responseBody": extract_static_response_from_callable(getattr(resource, f"on_{method.lower()}", None)),
                                "detectedBy": "static-scan",
                            })

            for child in getattr(node, "children", []):
                walk_falcon_node(child, path)

        # Start walking from root node
        root = getattr(router, "_roots", None) or getattr(router, "root", None)
        if isinstance(root, list):
            for r in root:
                walk_falcon_node(r)
        elif root:
            walk_falcon_node(root)

    except Exception:
        pass

    return endpoints


# ── Bottle ────────────────────────────────────────────────────────────────────
# Bottle stores all routes in app.routes (a list of Route objects)

def scan_bottle_routes(app):
    endpoints = []
    seen = set()

    try:
        for route in app.routes:
            path = route.rule
            method = route.method.upper()

            if method in ("HEAD", "OPTIONS"):
                continue
            if path in ("/static", "/_"):
                continue

            # Normalize <param> or <param:type> → :param
            normalized_path = re.sub(r"<([^:>]+)(?::[^>]+)?>", r":\1", path)
            normalized_path = normalized_path.rstrip("/") or "/"

            key = f"{method}:{normalized_path}"
            if key in seen:
                continue
            seen.add(key)

            handler_name = getattr(route.callback, "__name__", None)

            endpoints.append({
                "method": method,
                "path": normalized_path,
                "description": generate_description(method, normalized_path, handler_name),
                "requestBody": None,
                "responseBody": extract_static_response_from_callable(route.callback),
                "detectedBy": "static-scan",
            })

    except Exception:
        pass

    return endpoints


# ── aiohttp ───────────────────────────────────────────────────────────────────
# aiohttp stores routes in app.router which has a resources() method

def scan_aiohttp_routes(app):
    endpoints = []
    seen = set()

    try:
        for resource in app.router.resources():
            path = resource.canonical
            # Normalize {param} → :param
            normalized_path = re.sub(r"\{([^:}]+)(?::[^}]+)?\}", r":\1", path)
            normalized_path = normalized_path.rstrip("/") or "/"

            # Each resource has routes with methods
            for route in resource:
                method = route.method.upper()
                if method in ("HEAD", "OPTIONS", "*"):
                    continue

                key = f"{method}:{normalized_path}"
                if key in seen:
                    continue
                seen.add(key)

                handler = route.handler
                handler_name = getattr(handler, "__name__", None)

                endpoints.append({
                    "method": method,
                    "path": normalized_path,
                    "description": generate_description(method, normalized_path, handler_name),
                    "requestBody": None,
                    "responseBody": extract_static_response_from_callable(_resolve_view_handler(handler, method)),
                    "detectedBy": "static-scan",
                })

    except Exception:
        pass

    return endpoints


# ── Tornado ───────────────────────────────────────────────────────────────────
# Tornado stores URL specs in app.handlers. Each spec maps a path to a handler class.
# The handler class has methods like get(), post() etc. which we detect.

def scan_tornado_routes(app):
    endpoints = []
    seen = set()

    ALL_METHODS = ["get", "post", "put", "patch", "delete"]

    try:
        # Tornado stores handlers as a list of (host_pattern, [URLSpec, ...])
        handler_list = getattr(app, "handlers", [])

        for host_pattern, url_specs in handler_list:
            for spec in url_specs:
                # spec.regex is the compiled URL pattern
                # spec.handler_class is the RequestHandler subclass
                raw_path = spec.regex.pattern

                # Clean up regex artifacts → clean path
                path = raw_path
                path = re.sub(r"\(\?P<([^>]+)>[^)]+\)", r":\1", path)  # named groups
                path = re.sub(r"\([^)]+\)", ":param", path)  # unnamed groups
                path = re.sub(r"[\\^$?]", "", path)  # also remove ?
                path = re.sub(r"/+", "/", path)  # clean double slashes
                path = path.rstrip("/") or "/"
                if not path.startswith("/"):
                    path = "/" + path

                handler_class = spec.handler_class

                for method_name in ALL_METHODS:
                    # Skip if the handler only inherits the default 405 method
                    method_fn = getattr(handler_class, method_name, None)
                    if method_fn is None:
                        continue
                    # Check it's actually overridden (not just the base class stub)
                    if method_fn.__qualname__.startswith("RequestHandler."):
                        continue

                    method = method_name.upper()
                    key = f"{method}:{path}"
                    if key in seen:
                        continue
                    seen.add(key)

                    endpoints.append({
                        "method": method,
                        "path": path,
                        "description": generate_description(method, path, handler_class.__name__),
                        "requestBody": None,
                        "responseBody": extract_static_response_from_callable(getattr(handler_class, method_name, None)),
                        "detectedBy": "static-scan",
                    })

    except Exception:
        pass

    return endpoints


# ── Pyramid ───────────────────────────────────────────────────────────────────
# Pyramid uses an introspector to find all routes and their views.

def scan_pyramid_routes(app):
    endpoints = []
    seen = set()

    ALL_METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE"]

    try:
        registry = getattr(app, "registry", None)
        if registry is None:
            return endpoints

        introspector = getattr(registry, "introspector", None)
        if introspector is None:
            return endpoints

        # Get all route introspectables
        for intr in introspector.get_category("routes"):
            route = intr["introspectable"]
            path = route.get("pattern", "")

            # Normalize {param} → :param
            normalized_path = re.sub(r"\{([^:}]+)(?::[^}]+)?\}", r":\1", path)
            if not normalized_path.startswith("/"):
                normalized_path = "/" + normalized_path
            normalized_path = normalized_path.rstrip("/") or "/"

            route_name = route.get("name", "")

            # Try to find request_method predicate for this route
            related = introspector.related(intr["introspectable"])
            methods_found = set()
            view_callable = None   # the function that serves this route, used to guess its reply shape

            for rel in related:
                if view_callable is None and rel.get("callable"):
                    view_callable = rel.get("callable")
                predicates = rel.get("predicates", "")
                for method in ALL_METHODS:
                    if method in str(predicates):
                        methods_found.add(method)

            # If no method restriction found, assume GET and POST
            if not methods_found:
                methods_found = {"GET", "POST"}

            for method in methods_found:
                key = f"{method}:{normalized_path}"
                if key in seen:
                    continue
                seen.add(key)

                endpoints.append({
                    "method": method,
                    "path": normalized_path,
                    "description": generate_description(method, normalized_path, route_name),
                    "requestBody": None,
                    "responseBody": extract_static_response_from_callable(_resolve_view_handler(view_callable, method)),
                    "detectedBy": "static-scan",
                })

    except Exception:
        pass

    return endpoints


# ── CherryPy ──────────────────────────────────────────────────────────────────
# CherryPy uses a tree-based dispatcher. Routes are methods on classes.
# We walk the mounted apps and find exposed methods.

def scan_cherrypy_routes(app):
    endpoints = []
    seen = set()

    HTTP_METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE"]

    try:
        import cherrypy

        def walk_cherrypy_tree(obj, prefix=""):
            # Check if this object has exposed methods (HTTP handlers)
            for method_name in [m.lower() for m in HTTP_METHODS]:
                fn = getattr(obj, method_name, None)
                if fn and getattr(fn, "exposed", False):
                    method = method_name.upper()
                    path = prefix or "/"
                    key = f"{method}:{path}"
                    if key not in seen:
                        seen.add(key)
                        endpoints.append({
                            "method": method,
                            "path": path,
                            "description": generate_description(method, path, fn.__name__),
                            "requestBody": None,
                            "responseBody": extract_static_response_from_callable(fn),
                            "detectedBy": "static-scan",
                        })

            # index() is the default handler for the path (like GET /)
            index_fn = getattr(obj, "index", None)
            if index_fn and getattr(index_fn, "exposed", False):
                path = prefix or "/"
                key = f"GET:{path}"
                if key not in seen:
                    seen.add(key)
                    endpoints.append({
                        "method": "GET",
                        "path": path,
                        "description": generate_description("GET", path, "index"),
                        "requestBody": None,
                        "responseBody": extract_static_response_from_callable(index_fn),
                        "detectedBy": "static-scan",
                    })

            # Walk child attributes (sub-paths)
            visited = set()

            for attr_name in dir(obj):
                if attr_name.startswith("_"):
                    continue
                child = getattr(obj, attr_name, None)
                if child is None:
                    continue
                child_id = id(child)
                if child_id in visited:
                    continue
                visited.add(child_id)
                if hasattr(child, "exposed") or any(
                    hasattr(child, m.lower()) for m in HTTP_METHODS
                ):
                    walk_cherrypy_tree(child, prefix + "/" + attr_name)

        # Walk all mounted apps in cherrypy.tree
        for script_name, app_entry in cherrypy.tree.apps.items():
            root = getattr(app_entry, "root", None)
            if root:
                walk_cherrypy_tree(root, script_name)

    except Exception:
        pass

    return endpoints

# ── Static (build-time) scanning — no live app object required ──────────────
# Used by the CLI (bin/scan_endpoints.py) since there's no running server
# at build time. Parses .py files directly instead of introspecting a live
# app instance.

import os

SKIP_DIRS = {"node_modules", ".git", "venv", "env", ".venv", "__pycache__",
             "migrations", "dist", "build", ".tox", "site-packages"}


def scan_routes_static(cwd, framework):
    if framework in ("fastapi", "starlette", "sanic"):
        result = _scan_decorator_style_static(cwd)
    elif framework == "flask":
        result = _scan_flask_static(cwd)
    elif framework == "django":
        result = _scan_django_static(cwd)
    elif framework == "falcon":
        result = _scan_falcon_static(cwd)
    elif framework == "bottle":
        result = _scan_bottle_static(cwd)
    elif framework == "aiohttp":
        result = _scan_aiohttp_static(cwd)
    elif framework == "tornado":
        result = _scan_tornado_static(cwd)
    elif framework == "pyramid":
        result = _scan_pyramid_static(cwd)
    else:
        # CherryPy's routing is a runtime object tree discovered by
        # walking live class instances — it can't be approximated
        # reliably via static text scanning, so it's not supported for
        # build-time/serverless scans. The live interceptor still works
        # fine for CherryPy on always-on servers.
        result = []

    for endpoint in result:
        if "routeParamMap" not in endpoint:
            endpoint["routeParamMap"] = build_route_param_map(endpoint.get("path", ""))

    return result


def _walk_py_files(cwd):
    for root, dirs, files in os.walk(cwd):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
        for f in files:
            if f.endswith(".py"):
                yield os.path.join(root, f)


def _scan_decorator_style_static(cwd):
    """
    Handles FastAPI / Starlette / Sanic-style decorators:
      @app.get("/path")
      @router.post("/path")
    """
    endpoints = []
    seen = set()

    pattern = re.compile(
        r"@(?:\w+)\.(get|post|put|delete|patch)\s*\(\s*[\"']([^\"']+)[\"']",
        re.IGNORECASE,
    )

    for filepath in _walk_py_files(cwd):
        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as fh:
                content = fh.read()
        except Exception:
            continue

        tree = parse_source_tree(content)

        for match in pattern.finditer(content):
            method = match.group(1).upper()
            path = match.group(2)
            normalized = re.sub(r"\{([^}]+)\}", r":\1", path)
            key = f"{method}:{normalized}"
            if key in seen:
                continue
            seen.add(key)

            body_fields = _extract_body_fields_static(content) if method in ("POST", "PUT", "PATCH") else None

            endpoints.append({
                "method": method,
                "path": normalized,
                "description": generate_description(method, normalized, None),
                "requestBody": body_fields,
                "responseBody": extract_static_response_at(tree, content, match.start()),
                "detectedBy": "static-scan-file",
            })

    return endpoints


def _find_matching_paren(text, open_idx):
    """
    Given the index of an opening '(' in text, return the index of its
    matching closing ')'. Used to bound a single decorator's argument
    list precisely, instead of using a regex that can drift across
    unrelated decorators later in the file.
    """
    depth = 0
    i = open_idx
    n = len(text)
    while i < n:
        c = text[i]
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return None


def _scan_flask_static(cwd):
    """
    Handles Flask-style decorators:
      @app.route("/path", methods=["POST"])
      @bp.route("/path")   (Blueprint, defaults to GET)

    Each decorator's argument list is isolated using paren-matching
    (see _find_matching_paren) rather than a DOTALL regex. The previous
    DOTALL approach could match "methods=[...]" belonging to a LATER,
    unrelated @app.route(...) decorator further down the file, which
    both mis-tagged the earlier route's methods and caused the later
    route to be skipped entirely.
    """
    endpoints = []
    seen = set()

    decorator_start = re.compile(r"@(?:\w+)\.route\s*\(", re.IGNORECASE)

    for filepath in _walk_py_files(cwd):
        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as fh:
                content = fh.read()
        except Exception:
            continue

        tree = parse_source_tree(content)

        for start_match in decorator_start.finditer(content):
            open_paren_idx = start_match.end() - 1  # index of the '(' itself
            close_paren_idx = _find_matching_paren(content, open_paren_idx)
            if close_paren_idx is None:
                continue

            # Only look inside THIS decorator's own argument list
            args_text = content[open_paren_idx + 1:close_paren_idx]

            path_match = re.search(r"[\"']([^\"']+)[\"']", args_text)
            if not path_match:
                continue
            path = path_match.group(1)

            methods_match = re.search(r"methods\s*=\s*\[([^\]]*)\]", args_text)
            if methods_match:
                methods = [
                    m.strip().strip("'\"").upper()
                    for m in methods_match.group(1).split(",")
                    if m.strip()
                ]
                if not methods:
                    methods = ["GET"]
            else:
                methods = ["GET"]

            normalized = normalize_flask_path(path)

            for method in methods:
                key = f"{method}:{normalized}"
                if key in seen:
                    continue
                seen.add(key)

                body_fields = _extract_body_fields_static(content) if method in ("POST", "PUT", "PATCH") else None

                endpoints.append({
                    "method": method,
                    "path": normalized,
                    "description": generate_description(method, normalized, None),
                    "requestBody": body_fields,
                    "responseBody": extract_static_response_at(tree, content, start_match.start(), method),
                    "detectedBy": "static-scan-file",
                })

    return endpoints


def _scan_django_static(cwd):
    """
    Handles Django urls.py:
      path("users/<int:id>/", views.user_detail)
      re_path(r"^users/(?P<id>\\d+)/$", views.user_detail)
    """
    endpoints = []
    seen = set()

    pattern = re.compile(
        r"(?:path|re_path)\s*\(\s*r?[\"']([^\"']+)[\"']",
        re.IGNORECASE,
    )

    for filepath in _walk_py_files(cwd):
        if "urls.py" not in filepath:
            continue
        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as fh:
                content = fh.read()
        except Exception:
            continue

        for match in pattern.finditer(content):
            raw_path = match.group(1)
            normalized = _django_pattern_to_path(raw_path)

            # Static scan can't reliably detect the view's supported HTTP
            # methods without importing it — default to GET + POST as the
            # common case (consistent with function-based view fallback
            # in _detect_django_methods).
            for method in ["GET", "POST"]:
                key = f"{method}:{normalized}"
                if key in seen:
                    continue
                seen.add(key)

                endpoints.append({
                    "method": method,
                    "path": normalized,
                    "description": generate_description(method, normalized, None),
                    "requestBody": None,
                    "detectedBy": "static-scan-file",
                })

    return endpoints

def _scan_falcon_static(cwd):
    """
    Handles Falcon-style route registration:
      app.add_route('/path', SomeResource())
    Falcon resources define on_get/on_post/etc as class methods, so we
    can't perfectly link one add_route() call to its resource's methods
    without executing the code. As a best-effort approximation, we scan
    the whole file for any on_<method> definitions and apply that method
    set to every add_route() path found in the same file.
    """
    endpoints = []
    seen = set()

    route_pattern = re.compile(r"add_route\s*\(\s*[\"']([^\"']+)[\"']", re.IGNORECASE)
    method_def_pattern = re.compile(r"def\s+on_(get|post|put|delete|patch)\b", re.IGNORECASE)

    for filepath in _walk_py_files(cwd):
        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as fh:
                content = fh.read()
        except Exception:
            continue

        route_matches = list(route_pattern.finditer(content))
        if not route_matches:
            continue

        methods_in_file = sorted({m.group(1).upper() for m in method_def_pattern.finditer(content)})
        if not methods_in_file:
            methods_in_file = ["GET"]

        for match in route_matches:
            path = match.group(1)
            normalized = re.sub(r"\{([^:}]+)(?::[^}]+)?\}", r":\1", path)

            for method in methods_in_file:
                key = f"{method}:{normalized}"
                if key in seen:
                    continue
                seen.add(key)

                body_fields = _extract_body_fields_static(content) if method in ("POST", "PUT", "PATCH") else None

                endpoints.append({
                    "method": method,
                    "path": normalized,
                    "description": generate_description(method, normalized, None),
                    "requestBody": body_fields,
                    "detectedBy": "static-scan-file",
                })

    return endpoints


def _scan_bottle_static(cwd):
    """
    Handles Bottle-style routes:
      @app.route('/path', method='POST')
      @app.get('/path')  /  @app.post('/path')  (shorthand decorators)
    """
    endpoints = []
    seen = set()

    shorthand_pattern = re.compile(
        r"@(?:\w+)\.(get|post|put|delete|patch)\s*\(\s*[\"']([^\"']+)[\"']",
        re.IGNORECASE,
    )
    route_decorator_start = re.compile(r"@(?:\w+)\.route\s*\(", re.IGNORECASE)

    for filepath in _walk_py_files(cwd):
        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as fh:
                content = fh.read()
        except Exception:
            continue

        tree = parse_source_tree(content)

        for match in shorthand_pattern.finditer(content):
            method = match.group(1).upper()
            path = match.group(2)
            normalized = re.sub(r"<([^:>]+)(?::[^>]+)?>", r":\1", path)

            key = f"{method}:{normalized}"
            if key in seen:
                continue
            seen.add(key)

            body_fields = _extract_body_fields_static(content) if method in ("POST", "PUT", "PATCH") else None

            endpoints.append({
                "method": method,
                "path": normalized,
                "description": generate_description(method, normalized, None),
                "requestBody": body_fields,
                "responseBody": extract_static_response_at(tree, content, match.start()),
                "detectedBy": "static-scan-file",
            })

        for start_match in route_decorator_start.finditer(content):
            open_idx = start_match.end() - 1
            close_idx = _find_matching_paren(content, open_idx)
            if close_idx is None:
                continue
            args_text = content[open_idx + 1:close_idx]

            path_match = re.search(r"[\"']([^\"']+)[\"']", args_text)
            if not path_match:
                continue
            path = path_match.group(1)

            method_match = re.search(r"method\s*=\s*[\"'](\w+)[\"']", args_text)
            method = method_match.group(1).upper() if method_match else "GET"

            normalized = re.sub(r"<([^:>]+)(?::[^>]+)?>", r":\1", path)

            key = f"{method}:{normalized}"
            if key in seen:
                continue
            seen.add(key)

            body_fields = _extract_body_fields_static(content) if method in ("POST", "PUT", "PATCH") else None

            endpoints.append({
                "method": method,
                "path": normalized,
                "description": generate_description(method, normalized, None),
                "requestBody": body_fields,
                "responseBody": extract_static_response_at(tree, content, start_match.start()),
                "detectedBy": "static-scan-file",
            })

    return endpoints


def _scan_aiohttp_static(cwd):
    """
    Handles aiohttp-style route registration:
      app.router.add_get('/path', handler)
      app.router.add_post('/path', handler)
      app.router.add_route('POST', '/path', handler)
    """
    endpoints = []
    seen = set()

    shorthand_pattern = re.compile(
        r"add_(get|post|put|delete|patch)\s*\(\s*[\"']([^\"']+)[\"']",
        re.IGNORECASE,
    )
    generic_pattern = re.compile(
        r"add_route\s*\(\s*[\"'](\w+)[\"']\s*,\s*[\"']([^\"']+)[\"']",
        re.IGNORECASE,
    )

    for filepath in _walk_py_files(cwd):
        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as fh:
                content = fh.read()
        except Exception:
            continue

        for pattern in (shorthand_pattern, generic_pattern):
            for match in pattern.finditer(content):
                method = match.group(1).upper()
                path = match.group(2)
                normalized = re.sub(r"\{([^:}]+)(?::[^}]+)?\}", r":\1", path)

                key = f"{method}:{normalized}"
                if key in seen:
                    continue
                seen.add(key)

                body_fields = _extract_body_fields_static(content) if method in ("POST", "PUT", "PATCH") else None

                endpoints.append({
                    "method": method,
                    "path": normalized,
                    "description": generate_description(method, normalized, None),
                    "requestBody": body_fields,
                    "detectedBy": "static-scan-file",
                })

    return endpoints


def _scan_tornado_static(cwd):
    """
    Handles Tornado-style URL specs:
      (r"/path", SomeHandler)
    Tornado handler methods (get/post/etc) live on the handler class, so
    like Falcon, we approximate by scanning the whole file for any
    get/post/put/delete/patch method definitions and applying that set
    to every URL spec found in the same file. Only runs on files that
    look like Tornado app files, to avoid matching unrelated tuples.
    """
    endpoints = []
    seen = set()

    url_spec_pattern = re.compile(r"\(\s*r?[\"']([^\"']+)[\"']\s*,\s*(\w+)\s*\)")
    method_def_pattern = re.compile(r"def\s+(get|post|put|delete|patch)\s*\(\s*self", re.IGNORECASE)

    for filepath in _walk_py_files(cwd):
        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as fh:
                content = fh.read()
        except Exception:
            continue

        is_tornado_file = "tornado" in content.lower() and (
            "Application(" in content or "URLSpec" in content
        )
        if not is_tornado_file:
            continue

        url_matches = list(url_spec_pattern.finditer(content))
        if not url_matches:
            continue

        methods_in_file = sorted({m.group(1).upper() for m in method_def_pattern.finditer(content)})
        if not methods_in_file:
            methods_in_file = ["GET"]

        for match in url_matches:
            path = match.group(1)
            normalized = re.sub(r"\(\?P<([^>]+)>[^)]+\)", r":\1", path)
            normalized = re.sub(r"[\\^$]", "", normalized)
            if not normalized.startswith("/"):
                normalized = "/" + normalized

            for method in methods_in_file:
                key = f"{method}:{normalized}"
                if key in seen:
                    continue
                seen.add(key)

                body_fields = _extract_body_fields_static(content) if method in ("POST", "PUT", "PATCH") else None

                endpoints.append({
                    "method": method,
                    "path": normalized,
                    "description": generate_description(method, normalized, None),
                    "requestBody": body_fields,
                    "detectedBy": "static-scan-file",
                })

    return endpoints


def _scan_pyramid_static(cwd):
    """
    Handles Pyramid-style route registration:
      config.add_route('name', '/path')
    Static scan can't reliably determine which HTTP methods a route's
    view supports without executing the config, so — consistent with
    the Django static scanner's fallback — we default to GET + POST.
    """
    endpoints = []
    seen = set()

    pattern = re.compile(r"add_route\s*\(\s*[\"'][^\"']+[\"']\s*,\s*[\"']([^\"']+)[\"']")

    for filepath in _walk_py_files(cwd):
        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as fh:
                content = fh.read()
        except Exception:
            continue

        for match in pattern.finditer(content):
            path = match.group(1)
            normalized = re.sub(r"\{([^:}]+)(?::[^}]+)?\}", r":\1", path)
            if not normalized.startswith("/"):
                normalized = "/" + normalized

            for method in ("GET", "POST"):
                key = f"{method}:{normalized}"
                if key in seen:
                    continue
                seen.add(key)

                endpoints.append({
                    "method": method,
                    "path": normalized,
                    "description": generate_description(method, normalized, None),
                    "requestBody": None,
                    "detectedBy": "static-scan-file",
                })

    return endpoints


def _extract_body_fields_static(content):
    """
    Best-effort body field extraction from source text — mirrors the JS
    static file scanner's approach. Looks for common request-body access
    patterns without needing to import/execute the file.
    """
    fields = set()

    for m in re.finditer(r"request\.json(?:\.get\(|\[)\s*['\"]([a-zA-Z_][a-zA-Z0-9_]*)['\"]", content):
        fields.add(m.group(1))
    for m in re.finditer(r"request\.data(?:\.get\(|\[)\s*['\"]([a-zA-Z_][a-zA-Z0-9_]*)['\"]", content):
        fields.add(m.group(1))
    for m in re.finditer(r"request\.form(?:\.get\(|\[)\s*['\"]([a-zA-Z_][a-zA-Z0-9_]*)['\"]", content):
        fields.add(m.group(1))

    if not fields:
        return None

    properties = {f: {"type": infer_field_type(f, content)} for f in fields}
    return {"type": "object", "properties": properties}


def detect_framework_from_deps(cwd):
    """
    Detects the backend framework from dependency declarations, since
    Python has no single 'package.json' convention. Checks requirements.txt,
    pyproject.toml, and Pipfile, in that order.
    """
    FRAMEWORK_PACKAGES = [
        ("fastapi", "fastapi"),
        ("flask", "flask"),
        ("django", "django"),
        ("starlette", "starlette"),
        ("sanic", "sanic"),
        ("falcon", "falcon"),
        ("bottle", "bottle"),
        ("aiohttp", "aiohttp"),
        ("tornado", "tornado"),
        ("pyramid", "pyramid"),
        ("cherrypy", "cherrypy"),
    ]

    candidates = [
        os.path.join(cwd, "requirements.txt"),
        os.path.join(cwd, "pyproject.toml"),
        os.path.join(cwd, "Pipfile"),
    ]

    combined = ""
    for filepath in candidates:
        if os.path.exists(filepath):
            try:
                with open(filepath, "r", encoding="utf-8", errors="ignore") as fh:
                    combined += fh.read().lower() + "\n"
            except Exception:
                continue

    for pkg_name, framework in FRAMEWORK_PACKAGES:
        if pkg_name in combined:
            return framework

    return None

# ── Static response-shape guessing ───────────────────────────────────────────
# Best-effort: reads field names from reply objects written out directly in the code
# (e.g. return {"id": 1, "name": "x"} or jsonify({...})). Replies built from variables are
# left empty on purpose; real runtime replies fill those in later and replace any guess.

MAX_STATIC_RESPONSE_FIELDS = 50
_STATIC_REPLY_FUNCS = {
    "jsonify", "JSONResponse", "ORJSONResponse", "UJSONResponse", "JsonResponse",
    "json_response", "json", "Response", "write",
}


def _static_func_name(call):
    f = call.func
    if isinstance(f, ast.Name):
        return f.id
    if isinstance(f, ast.Attribute):
        return f.attr
    return ""


def _static_dict_entries(d):
    # Spreads (**x) and non-text keys are skipped
    return [
        (k.value, v) for k, v in zip(d.keys, d.values)
        if isinstance(k, ast.Constant) and isinstance(k.value, str)
    ]


def _static_status(node, default=200):
    if isinstance(node, ast.Constant) and isinstance(node.value, int):
        return node.value
    name = node.attr if isinstance(node, ast.Attribute) else getattr(node, "id", "")
    m = re.search(r"(?:^|_)([45]\d\d)(?:_|$)", name or "")
    return int(m.group(1)) if m else default


def _static_value_type(node):
    # Only literal values reveal their type; anything computed is marked "unknown"
    if isinstance(node, ast.Constant):
        v = node.value
        if isinstance(v, bool):
            return {"type": "boolean"}
        if isinstance(v, (int, float)):
            return {"type": "number"}
        if isinstance(v, str):
            return {"type": "string"}
        return {"type": "unknown"}
    if isinstance(node, ast.JoinedStr):
        return {"type": "string"}
    if isinstance(node, (ast.List, ast.Tuple)):
        return {"type": "array", "items": {"type": "unknown"}}
    if isinstance(node, ast.Dict):
        return {"type": "object"}
    return {"type": "unknown"}


def _static_reply_entries(node):
    """If this piece of code sends a reply written as an object, returns (entries, status)."""
    status = 200
    if isinstance(node, ast.Return) and node.value is not None:
        value = node.value
        if isinstance(value, ast.Tuple) and value.elts:
            if len(value.elts) > 1:
                status = _static_status(value.elts[1])
            value = value.elts[0]
        if isinstance(value, ast.Dict):
            return _static_dict_entries(value), status
        return None
    if isinstance(node, ast.Call) and _static_func_name(node) in _STATIC_REPLY_FUNCS:
        for kw in node.keywords:
            if kw.arg in ("status", "status_code"):
                status = _static_status(kw.value)
        if node.args and isinstance(node.args[0], ast.Dict):
            return _static_dict_entries(node.args[0]), status
        for kw in node.keywords:
            if kw.arg in ("content", "data", "body") and isinstance(kw.value, ast.Dict):
                return _static_dict_entries(kw.value), status
        if _static_func_name(node) == "jsonify" and not node.args and node.keywords:
            return [(kw.arg, kw.value) for kw in node.keywords if kw.arg], status
        return None
    if isinstance(node, ast.Assign) and isinstance(node.value, ast.Dict):
        if any(isinstance(t, ast.Attribute) and t.attr == "media" for t in node.targets):
            return _static_dict_entries(node.value), status
    return None


def extract_response_from_ast(root):
    """Finds the first successful reply written as an object inside a function."""
    try:
        # replies sent with an error status, e.g. `return jsonify({...}), 404`, are not the normal shape
        error_ids = set()
        for node in ast.walk(root):
            if isinstance(node, ast.Return) and isinstance(node.value, ast.Tuple) and len(node.value.elts) > 1:
                if _static_status(node.value.elts[1]) >= 400:
                    error_ids.add(id(node.value.elts[0]))

        found = []
        for node in ast.walk(root):
            if id(node) in error_ids:
                continue
            reply = _static_reply_entries(node)
            if reply:
                found.append((getattr(node, "lineno", 0), reply))
        found.sort(key=lambda item: item[0])

        for _, (entries, status) in found:
            if status >= 400:
                continue
            properties = {}
            for key, value in entries[:MAX_STATIC_RESPONSE_FIELDS]:
                properties[key] = _static_value_type(value)
            if not properties:
                continue
            if list(properties.keys()) == ["error"]:      # looks like an error reply
                continue
            # "_source" lets the server replace this guess with a real runtime reply later
            return {"type": "object", "properties": properties, "_source": "static"}
    except Exception:
        pass
    return None


class _ScopedHandler:
    """A handler function together with the HTTP method it was resolved for."""
    def __init__(self, fn, method):
        self.fn = fn
        self.method = method


def _method_test(test):
    """If this condition checks the request's HTTP method, returns (set of methods, is_negated); else None."""
    if not isinstance(test, ast.Compare) or len(test.ops) != 1 or len(test.comparators) != 1:
        return None
    left = test.left
    if (isinstance(left, ast.Call) and isinstance(left.func, ast.Attribute)
            and left.func.attr in ("upper", "lower") and not left.args):
        left = left.func.value
    # any name or attribute that holds the request method (request.method, method, http_method, ...)
    is_method = (isinstance(left, ast.Attribute) and "method" in left.attr.lower()) or (
        isinstance(left, ast.Name) and "method" in left.id.lower())
    if not is_method:
        return None
    right = test.comparators[0]
    if isinstance(right, ast.Constant) and isinstance(right.value, str):
        values = [right.value]
    elif isinstance(right, (ast.Tuple, ast.List, ast.Set)) and all(
            isinstance(e, ast.Constant) and isinstance(e.value, str) for e in right.elts):
        values = [e.value for e in right.elts]
    else:
        return None
    # only real HTTP method names count (ignores things like payment_method == "card")
    if not values or not all(
        v.upper() in ("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS") for v in values
    ):
        return None
    op = test.ops[0]
    if isinstance(op, (ast.Eq, ast.In)):
        negated = False
    elif isinstance(op, (ast.NotEq, ast.NotIn)):
        negated = True
    else:
        return None
    return {v.upper() for v in values}, negated


def _isolate_method_code(stmts, method, tail=()):
    """Returns the statements that run for one HTTP method (None if no method check is found here)."""
    for idx, stmt in enumerate(stmts):
        if not isinstance(stmt, ast.If):
            continue
        info = _method_test(stmt.test)
        if not info:
            continue
        methods, negated = info
        if (method in methods) != negated:
            return list(stmt.body)                       # this branch belongs to our method
        after = list(stmts[idx + 1:]) + list(tail)       # code that runs when the branch is skipped
        if stmt.orelse:
            deeper = _isolate_method_code(stmt.orelse, method, after)
            return deeper if deeper is not None else list(stmt.orelse) + after
        deeper = _isolate_method_code(after, method)
        return deeper if deeper is not None else after
    return None


def _scope_to_method(func_node, method):
    """Narrows a handler to the code for one HTTP method. Returns the whole handler when it never checks
    the method, and None (no guess) when it checks the method in a way we cannot follow."""
    if not method:
        return func_node
    has_check = any(isinstance(n, ast.Compare) and _method_test(n) for n in ast.walk(func_node))
    if not has_check:
        return func_node
    stmts = _isolate_method_code(func_node.body, method.upper())
    if stmts is None:
        return None
    return ast.Module(body=stmts, type_ignores=[])


def _resolve_view_handler(callback, method):
    """Finds the actual function that handles one HTTP method (function, class-based view, ViewSet)."""
    if callback is None:
        return None
    m = method.lower()
    cls = getattr(callback, "view_class", None) or getattr(callback, "cls", None)
    if cls is None and inspect.isclass(callback):
        cls = callback
    if cls is not None:
        actions = getattr(callback, "actions", None)
        name = actions.get(m, m) if isinstance(actions, dict) else m
        return getattr(cls, name, None)
    return _ScopedHandler(callback, method)   # plain function: remember which method it was resolved for


def extract_static_response_from_callable(fn, method=None):
    """For live apps: reads a handler function's source and looks for a written-out reply."""
    try:
        if isinstance(fn, _ScopedHandler):
            fn, method = fn.fn, fn.method
        if fn is None:
            return None
        fn = inspect.unwrap(fn)
        tree = ast.parse(textwrap.dedent(inspect.getsource(fn)))
        if tree.body and isinstance(tree.body[0], (ast.FunctionDef, ast.AsyncFunctionDef)):
            scoped = _scope_to_method(tree.body[0], method)
            return extract_response_from_ast(scoped) if scoped is not None else None
    except Exception:
        pass
    return None


def parse_source_tree(content):
    try:
        return ast.parse(content)
    except Exception:
        return None


def extract_static_response_at(tree, content, char_index, method=None):
    """For file scans: finds the function that owns the route written at this position in the file."""
    try:
        if tree is None:
            return None
        line = content.count("\n", 0, char_index) + 1
        owners = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                start = min([d.lineno for d in node.decorator_list] or [node.lineno])
                end = getattr(node, "end_lineno", None)
                if end and start <= line <= end:
                    owners.append((start, node))
        if not owners:
            return None
        scoped = _scope_to_method(max(owners, key=lambda o: o[0])[1], method)   # innermost function
        return extract_response_from_ast(scoped) if scoped is not None else None
    except Exception:
        return None


def _schema_has_fields(schema):
    if not schema:
        return False
    if schema.get("type") == "array":
        return _schema_has_fields(schema.get("items"))
    return bool(schema.get("properties"))


def _simplify_json_schema(schema, defs, depth=0):
    """Flattens a pydantic JSON schema into the same simple shape the runtime capture produces."""
    if not isinstance(schema, dict) or depth > 4:
        return {"type": "object"}
    if "$ref" in schema:
        target = defs.get(schema["$ref"].split("/")[-1])
        return _simplify_json_schema(target, defs, depth + 1) if target else {"type": "object"}
    for key in ("anyOf", "oneOf", "allOf"):
        if key in schema:
            options = [s for s in schema[key] if not (isinstance(s, dict) and s.get("type") == "null")]
            return _simplify_json_schema(options[0], defs, depth + 1) if options else {"type": "string"}
    t = schema.get("type")
    if t == "object" or "properties" in schema:
        props = {}
        for k, v in list(schema.get("properties", {}).items())[:MAX_STATIC_RESPONSE_FIELDS]:
            props[k] = _simplify_json_schema(v, defs, depth + 1)
        return {"type": "object", "properties": props} if props else {"type": "object"}
    if t == "array":
        return {"type": "array", "items": _simplify_json_schema(schema.get("items", {}), defs, depth + 1)}
    if t in ("string", "integer", "number", "boolean"):
        return {"type": t}
    return {"type": "string"}


def extract_fastapi_response_schema(route):
    """FastAPI declares its reply shape (response_model / return type) — use it directly."""
    try:
        model = getattr(route, "response_model", None)
        if model is None:
            return None
        schema = None
        if hasattr(model, "model_json_schema"):
            schema = model.model_json_schema()
        else:
            try:
                from pydantic import TypeAdapter
                schema = TypeAdapter(model).json_schema()
            except Exception:
                if hasattr(model, "schema"):
                    schema = model.schema()
        if not schema:
            return None
        defs = schema.get("$defs") or schema.get("definitions") or {}
        simplified = _simplify_json_schema(schema, defs, 0)
        if not _schema_has_fields(simplified):
            return None
        simplified["_source"] = "static"
        return simplified
    except Exception:
        return None